import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-address',
  templateUrl: './address.component.html',
  styleUrls: ['./address.component.scss']
})
export class AddressComponent implements OnInit {

  constructor() { }
  public companyName:string ='Mobilects Software Solutions';
  public brandName:string ='mobilectsoftware';
  public domainName:string ='mobilectsoftware';
  public websiteName:string ='www.mobilects.com';

  ngOnInit() {
  }

}
