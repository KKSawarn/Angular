import { NgModule} from '@angular/core';
import {MatButtonModule, MatMenuModule, MatToolbarModule, MatCheckboxModule, MatSidenavModule, MatExpansionModule, MatCardModule} from '@angular/material';
import {MatIconModule} from '@angular/material/icon';
import {MatListModule} from '@angular/material/list';
import { NgMatSearchBarModule } from 'ng-mat-search-bar';
import {MatDividerModule} from '@angular/material/divider';
import {MatTabsModule} from '@angular/material/tabs';


 
const MaterialComponents =[ 
  MatExpansionModule,
  NgMatSearchBarModule,
   MatButtonModule,
   MatCheckboxModule,
   MatDividerModule,
   MatMenuModule,
   MatIconModule,
   MatToolbarModule,
  MatSidenavModule,
  MatListModule,
  MatTabsModule,
  MatCardModule ];
@NgModule({
  imports: [ MaterialComponents],
  exports: [ MaterialComponents]
})
export class MaterialModule { }
